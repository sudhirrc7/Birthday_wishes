package dao;

import java.util.ArrayList;
import java.util.List;
import model.Book;

public class BookDAO {
    private static List<Book> books = new ArrayList<>();

    public static void addBook(Book book) {
        books.add(book);
    }

    public static List<Book> getAllBooks() {
        return books;
    }
}


    public static void updateBook(Book book) {
        try {
            Connection conn = DB.getConnection();
            PreparedStatement ps = conn.prepareStatement("UPDATE books SET title=?, author=?, genre=? WHERE id=?");
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getGenre());
            ps.setInt(4, book.getId());
            ps.executeUpdate();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteBook(int id) {
        try {
            Connection conn = DB.getConnection();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM books WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
