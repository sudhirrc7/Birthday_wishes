package model;

public class Book {
    private int id;
    private String bookName;
    private String authorName;
    private double price;

    public Book(int id, String bookName, String authorName, double price) {
        this.id = id;
        this.bookName = bookName;
        this.authorName = authorName;
        this.price = price;
    }

    public int getId() { return id; }
    public String getBookName() { return bookName; }
    public String getAuthorName() { return authorName; }
    public double getPrice() { return price; }
}
