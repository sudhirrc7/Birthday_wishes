package servlet;

import model.Book;
import dao.BookDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class AddBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String bookName = request.getParameter("bookName");
        String authorName = request.getParameter("authorName");
        double price = Double.parseDouble(request.getParameter("price"));

        Book book = new Book(0, bookName, authorName, price);
        BookDAO.addBook(book);

        response.sendRedirect("adminDashboard.jsp");
    }
}
