package dao;

import java.util.HashMap;

public class UserDAO {
    static HashMap<String, String> adminUsers = new HashMap<>();
    static HashMap<String, String> customerUsers = new HashMap<>();

    static {
        adminUsers.put("admin", "admin123");
        customerUsers.put("user", "user123");
    }

    public static boolean validateAdmin(String username, String password) {
        return adminUsers.containsKey(username) && adminUsers.get(username).equals(password);
    }

    public static boolean validateCustomer(String username, String password) {
        return customerUsers.containsKey(username) && customerUsers.get(username).equals(password);
    }
}
