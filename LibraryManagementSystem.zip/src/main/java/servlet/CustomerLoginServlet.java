package servlet;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
import dao.UserDAO;

public class CustomerLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (UserDAO.validateCustomer(username, password)) {
            response.sendRedirect("customerDashboard.jsp");
        } else {
            response.getWriter().println("Invalid Customer Credentials");
        }
    }
}
